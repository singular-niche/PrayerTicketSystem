<?php return array (
'Build-Date' => 'Tue, 17 Oct 17 16:48:19 -0100',
'Build-Version' => 'v1.10.1',
'Language' => 'en_US_custom',
'Id' => 'lang:en',
'Last-Revision' => '2017-10-17 12:15-0100',
'Version' => 141455,
);